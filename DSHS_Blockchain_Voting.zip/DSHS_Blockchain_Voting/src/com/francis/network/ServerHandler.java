package com.francis.network;

import java.io.IOException;
import java.net.Socket;

/**
 * ServerHandler
 */

public class ServerHandler extends Thread {
    private Socket _socket = null; // 서버 소켓
    public ServerManager _svrMgr = null; // 서버 매니저 객체

    // 생성자
    public ServerHandler(ServerManager svrMgr, Socket socket) {
        _svrMgr = svrMgr;
        _socket = socket;
    }

    /** 루프를 돌려서 클라이언트로부터 메세지를 받을때까지 대기
     * 연결이 끊기면 클라이언트를 삭제
     */
    @Override
    public void run() {
        while (true) {
            try {
                _svrMgr.receiveMsg(_socket); // 메세지를 수신
            } catch(IOException | ClassNotFoundException e) {
                _svrMgr.clientDisconnected(_socket); // 예외처리
                break;
            }
        }
    }
}
