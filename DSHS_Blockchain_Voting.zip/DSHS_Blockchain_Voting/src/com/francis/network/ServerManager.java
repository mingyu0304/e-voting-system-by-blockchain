package com.francis.network;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.atomic.AtomicInteger;

import javax.crypto.SealedObject;


/**
 * ServerManager
 *
 * Responsible for all the network communications in server side.
 *
 * In a new thread, it will run a loop accepting all the incoming clients
 * and create a new instance of ServerHandler in a new thread reading incoming
 * message from connected clients.
 *
 * In the main thread, it provides a message handler handling all the incoming
 * messages. Also, it has interfaces serving ClusterManager.
 */

// NetworkManager 상속
public class ServerManager extends NetworkManager {
    private ServerSocket _svrSocket = null; // 서버 소켓

    private volatile AtomicInteger _cid = null; // 접속하는 클라이언트의 번호를 부여, volatile : Main Memory 저장하여 멀티스레드 환경에서의 문제를 방지
    private volatile Map<Integer, Socket> _clients = null; // 클라이언트 번호와 소켓을 매핑하여 저장, volatile keyword 사용
    // volatile : https://nesoy.github.io/articles/2018-06/Java-volatile

    // 생성자
    public ServerManager(int svrPort) {
        try {
            _clients = new ConcurrentSkipListMap<Integer, Socket>();
            _cid = new AtomicInteger(0);

            _svrSocket = new ServerSocket(svrPort); // 서버 소켓 생성

            System.out.println("Waiting for clients...");
            System.out.println("Please connect to " + InetAddress.getLocalHost() + ":" + svrPort + ".");
        } catch (IOException e) {
            System.out.println("ERROR: failed to listen on port " + svrPort); // 예외처리
            e.printStackTrace();
        }
    }

    // 루프를 돌려서 클라이언트를 대기하고 스레드를 형성
    @Override
    public void run() {
        while(true) {
            try {
                Socket socket = _svrSocket.accept(); // 클라이언트를 대기하여 연결
                addClient(socket); // 클라이언트 추가
                System.out.println("New client(cid is " + getCid(socket) + ") connected!");

                /* 클라이언트로부터 메세지를 받기 위해서 클라이언트와 네트워킹 시켜준다 */
                new ServerHandler(this, socket).start();
                /* 클라이언트에게 새로운 클라이언트 아이디에 대한 메세지를 전달한다 */
                sendMsg(socket, new MessageStruct(2, Integer.valueOf(getCid(socket)))); // code 2 : 서버에서 clientID(클라이언트 번호) 전송
            } catch (IOException e) {
                // 예외처리 :  서버가 닫힐 때
                break;
            }
        }
    }

    // 클라이언트 연결 종료
    public void clientDisconnected(Socket client) {
        int cid = getCid(client);
        System.out.println("Client " + cid + " has disconnected.");

        deleteClient(cid);
    }

    /* ================== Message handlers begin ==================*/

    // MessageStruct 의 코드별로 처리
    @Override
    public void msgHandler(MessageStruct msg, Socket src) {
        switch(msg._code) {
            case 0:
                // ClientManager 에서 처리할 부분
                break;
            case 1:
                System.out.println("Broadcasting : " + (String)msg._content.toString()); // 어떤 메세지를 브로드캐스팅 하는지 출력(디버깅)

                // 블록 브로드캐스팅 : 블록체인의 중요한 특징을 구현
                broadcast((SealedObject)msg._content, src);
                break;
            default:
                break;
        }
    }

    // 브로드캐스팅 구현
    private void broadcast(SealedObject o, Socket src) {

        // 다른 모든 클라이언트(소켓)에게 브로드캐스팅
        int srcCid = getCid(src); // 투표를 한 클라이언트의 번호
        for(int i = _cid.get() - 1; i >= 0; i--) {
            // 본인에게는 다시 전송하지 않음
            if(i != srcCid) {
                try {
                    sendMsg(getClient(i), new MessageStruct(0, o)); // 다른 모든 클라이언트에게 메세지 전송
                } catch (IOException e) {
                    System.out.println("ERROR: Connection with " + srcCid + " is broken, message cannot be sent!"); // 예외처리
                    e.printStackTrace();
                } catch (NullPointerException e) {
                    continue;
                }
            }
        }
    }

    /* ================== Message handlers end ==================*/

    /* ================== Client info manage methods begin ==================*/

    // 클라이언트를 시드와 소켓으로 매핑하여 _clients 에 추가
    private void addClient(Socket socket) {
        _clients.put(Integer.valueOf(_cid.getAndIncrement()), socket);
    }

    // 클라이언트 제거 : 매핑 한 부분에서 삭제
    private boolean deleteClient(int idx) {
        if (_clients.remove(Integer.valueOf(idx)) == null) {
            System.out.println("delete failed!");
            return false;
        }
        return true;
    }

    // 시드를 통해 클라이언트 소켓을 반환
    private Socket getClient(int cid) {
        return (Socket)_clients.get(Integer.valueOf(cid));
    }

    // 소켓을 통해 클라이언트 시드를 반환
    private int getCid(Socket socket) {
        for (Map.Entry<Integer, Socket> entry : _clients.entrySet()) {
            if (entry.getValue() == socket) {
                return entry.getKey().intValue();
            }
        }
        return -1;
    }

    /* ================== Client info manage methods end ==================*/

    // 종료
    public void close() {
        System.out.println("Server is about to close. All connected clients will exit.");
        try {
            _svrSocket.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("Bye~");
    }
}
