package com.francis.network;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;


/**
 * NetworkManager
 * ServerManager, ClientManager 의 추상 클래스
 * 기본적인 네트워크 작용을 제공
 */

public abstract class NetworkManager implements Runnable {
    // 메세지 전송
    public void sendMsg(Socket socket, MessageStruct msg) throws IOException {
        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream()); // 출력스트림 생성
        out.writeObject(msg); // 메세지 전송
    }

    // 메세지 수신
    public void receiveMsg(Socket socket) throws ClassNotFoundException, IOException {
        ObjectInputStream inStream = new ObjectInputStream(socket.getInputStream()); // 입력스트림 생성
        Object inObj = inStream.readObject();

        // inObj 가 MessageStruct 의 인스터스인 경우
        if (inObj instanceof MessageStruct) {
            MessageStruct msg = (MessageStruct) inObj; // 강제 변환
            msgHandler(msg, socket); // msgHandler 호출
        }

    }

    // 소켓 종료
    public void close(Socket socket) {
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 추상 메소드 : 메세지를 코드별로 다르게 처리
    public abstract void msgHandler(MessageStruct msg, Socket src);
}
