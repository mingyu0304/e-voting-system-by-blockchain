package com.francis.network;

import java.io.BufferedReader;
import java.io.File;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;

import javax.crypto.Cipher;
import javax.crypto.SealedObject;
import javax.crypto.spec.SecretKeySpec;

import com.francis.blockchain.*;

import static com.francis.main.Main.decrypt;

/**
 * ClientManager
 * 서버와의 통신과정에서 클라이언트에 대한 모든 기능을 제공
 * Main 에서 새로운 클라이언트와 서버와의 스레드를 형성
 */


// NetworkManager 를 상속
public class ClientManager extends NetworkManager {
    public static int difficulty = 3; // 임시로 3으로 설정

    private Socket _socket = null; // 서버와의 통신을 위한 소켓
    private Block genesisBlock; // 최초의 블록
    private ArrayList<SealedObject> blockList; // 블록체인
    private ArrayList<String> parties; // 후보자 명단
    private ArrayList<Wallet> partiesWallet;
    private HashSet<String> hashVotes;
    private String prevHash = "0"; // 최초의 블록의 prevHash

    private int clientId;

    // 생성자
    public ClientManager(String addr, int port) {
        try {
            _socket = new Socket(addr, port); // 서버와의 소켓 형성
            System.out.println("Connected to server: " + addr + ":" + port);
            genesisBlock = new Block(prevHash); // 최초의 블록 생성
            hashVotes = new HashSet<>();

            // 후보자 명단
            parties = new ArrayList<>();
            parties.add("윤유상");
            parties.add("장민우");
            parties.add("김민규");

            blockList = new ArrayList<>();
            addBlock(genesisBlock); // 블록체인에 최초의 블록 추가
            prevHash = genesisBlock.getBlockHash();
        } catch (IOException e) {
            System.out.println("Cannot connect to server " + addr + ":" + port); // 예외처리
            e.setStackTrace(e.getStackTrace());
            System.exit(0);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    // 블록을 블록체인에 추가
    public void addBlock(Block newBlock) throws Exception {
        newBlock.mineBlock(difficulty);
        blockList.add(encrypt(newBlock));
    }

    // 클라이언트 통신 시작
    public void startClient() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); // 입력버퍼 생성
        System.out.println("Welcome to Voting Machine ! ");
        String choice = "y";
        do {
            Block blockObj = null; // 블록 객체

            // 인스턴스 변수
            String voterId = null;
            String voterName = null;
            String voteParty = null;

            try {
                System.out.print("Enter Voter ID : ");
                voterId = br.readLine();
                System.out.print("Enter Voter Name : ");
                voterName = br.readLine();

                Wallet myWallet = new Wallet();

                System.out.println("Vote for parties:");
                int voteChoice;

                partiesWallet = new ArrayList<Wallet>();

                do {
                    // 후보자 명단 출력
                    for (int i = 0; i < parties.size(); i++) {
                        System.out.println((i + 1) + ". " + parties.get(i));
                        Wallet partyWallet = new Wallet(); // ***** 바꿔야됨 voteParty 와 후보자의 PublicKey 를 매핑해야 하면 이것은 임시적은 코드
                        partiesWallet.add(partyWallet);
                    }

                    System.out.println("Enter your Vote : ");
                    voteParty = br.readLine();
                    voteChoice = Integer.parseInt(voteParty);
                    if (voteChoice > parties.size() || voteChoice < 1)
                        System.out.println("Please enter correct index .");
                    else
                        break;
                } while (true);

                voteParty = parties.get(voteChoice - 1); // 투표한 후보자
                blockObj = new Block(prevHash);
                blockObj.addVote(myWallet.throwVote(partiesWallet.get(voteChoice - 1).getPublicKey(), voterName, voterId, voteParty)); // 블록 생성

                // 블록 검증
                if (checkValidity(blockObj)) {
                    hashVotes.add(voterId); // voterId 추가, 중복 방지
                    sendMsg(new MessageStruct(1, encrypt(blockObj))); // code : 1 -> 새로운 블록을 브로드캐스팅

                    addBlock(blockObj); // 블록체인에 추가
                    prevHash = blockObj.getBlockHash(); // prevHash 업데이트
                } else {
                    System.out.println("Vote Invalid.");
                }
                System.out.println("Cast Another Vote (y/n) ? ");
                choice = br.readLine();

            } catch (IOException e) {
                System.out.println("ERROR: read line failed!"); // 예외처리
                return;
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace(); // 예외처리
            }
        } while (choice.equals("y") || choice.equals("Y"));
        close(); // 입력버퍼 종료
    }

    // 블록 암호화
    public SealedObject encrypt(Block b) throws Exception {
        SecretKeySpec sks = new SecretKeySpec("MyDifficultPassw".getBytes(), "AES");

        // Create cipher
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");

        //Code to write your object to file
        cipher.init(Cipher.ENCRYPT_MODE, sks);

        return new SealedObject(b, cipher);
    }

    // 아이디 중복 검증 -> 전화번호 중복 검증
    private boolean checkValidity(Block blockObj) {
        return !hashVotes.contains((String) blockObj.getVoteObj().getVoterId());
    }

    // 메세지 전송
    public void sendMsg(MessageStruct msg) throws IOException {
        sendMsg(_socket, msg);
    }

    // 소켓 종료
    public void close() {
        // 파일 위치 지정하기
        String userHomePath = System.getProperty("user.home");
        String fileName;
        fileName = userHomePath + "/Desktop/blockchain_data";
        File f = new File(fileName);

        // 파일 생성
        try {
            if(!f.exists())
                f.createNewFile();
            else {
                f.delete();
                f.createNewFile();
            }

            System.out.println(fileName);

            ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(fileName, true)); // 출력스트림 생성
            o.writeObject(blockList); // 파일에 암호회된 블록체인 출력

            o.close(); // 출력스크림 종료
            _socket.close(); // 소켓 종료
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace(); // 예외처리
        }

        System.exit(0); // 시스템 종료
    }

    // msgHandler 재정의 : 케이스마다 다르게 처리
    @Override
    public void msgHandler(MessageStruct msg, Socket src) {
        // 메세지 구조중 code 에 따른 처리
        switch(msg._code) {
            case 0:
                // message type sent from server to client
                // 메세지를 서버로부터 수신
                try {
                    Block decryptedBlock = (Block) decrypt((SealedObject) msg._content); // 블록 해독
                    addBlock(decryptedBlock); // 암호화된 블록을 블록체인에 추가
                    hashVotes.add(decryptedBlock.getVoteObj().getVoterId()); // hashVote 에 clientID 추가
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace(); // 예외처리
                }
                break;
            case 1:
                // message type sent from broadcast to all clients
                // 서버의 msgHandler 에서 처리할 부분
                break;
            case 2:
                clientId = (int) (msg._content); // clientID 를 수신
            default:
                break;
        }
    }

    // 루프를 돌려서 서버로부터 메세지를 받을때까지 대기
    @Override
    public void run() {
        while(true) {
            try {
                receiveMsg(_socket); // 메세지 수신
            } catch(ClassNotFoundException | IOException e) {
                // 예외처리
                if(_socket.isClosed()) {
                    System.out.println("Bye.");
                    System.exit(0);
                }

                System.out.println("Connection to server is broken. Please restart client.");
                close(_socket);
                System.exit(-1);
            }
        }
    }
}
