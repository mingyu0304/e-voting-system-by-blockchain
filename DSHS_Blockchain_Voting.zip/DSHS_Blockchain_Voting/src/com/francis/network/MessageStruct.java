package com.francis.network;

import java.io.Serializable;

/**
 * MessageStruct
 * server 와 client 가 상호작용하기 위한 구조
 * message type(_code)와 message body(_content)로 이루어져 있음.
 *
 * 메세지 타입과 메세지 전달 방향:
 *          type description				direction
 * 0		server broadcasts block			server -> client
 * 1		client sends block  			client -> server
 * 2		server sends clientID			server -> client
 */

public class MessageStruct extends Object implements Serializable {
    private static final long serialVersionUID = 3532734764930998421L;
    public int _code;
    public Object _content;

    // 생성자
    public MessageStruct() {
        this._code = 0;
        this._content = null;
    }

    // 생성자
    public MessageStruct(int code, Object content) {
        this._code = code;
        this._content = content;
    }
}
