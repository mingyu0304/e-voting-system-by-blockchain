package blockchain_evoting;

import java.io.BufferedReader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.HashMap;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SealedObject;
import javax.crypto.spec.SecretKeySpec;
import static java.nio.file.attribute.PosixFilePermission.*;

/**
 * ClientManager
 *
 * Responsible for all the network communications in client side.
 *
 * In a new thread, it will run a loop receiving messages sent from server and
 * dispatch it to the main thread to handle.
 *
 * In the main thread, it provides a message handler handling all the incoming
 * messages. Also, it has interfaces serving ProcessManager.
 *
 */
public class ClientManager extends NetworkManager {

   public static int difficulty = 3; // 임시로 3으로 설정

   /* the socket communicating with server */
   private Socket _socket = null;
   private Block genesisBlock;
   private ArrayList<SealedObject> blockList;
   ArrayList<Block> chkBlock = new ArrayList<Block>();

   public ArrayList<SealedObject> getBlockList() {
      return blockList;
   }

   private ArrayList<String> parties = null;
   private ArrayList<Wallet> partiesWallet;
   private HashSet<String> hashVotes;
   private String prevHash = "0";
   private Frame f = null;
   private Frame f5 = null;
   private int width, height;
   private String voterPhoneNumber;

   public void set_FrameInfo(Frame f, int width, int height) {
      this.f = f;
      this.width = width;
      this.height = height;
   }

   private int clientId;

   public ClientManager(String addr, int port) {
      try {
         _socket = new Socket(addr, port);
         System.out.println("Connected to server: " + addr + ":" + port);
         genesisBlock = new Block(prevHash);
         hashVotes = new HashSet<>();
         blockList = new ArrayList<>();
         addBlock(genesisBlock);
         prevHash = genesisBlock.getBlockHash();

         System.out.print("genesisBlock: ");
         System.out.println(genesisBlock);
         System.out.println(prevHash);
      } catch (IOException e) {
         System.out.println("Cannot connect to server " + addr + ":" + port);
         e.setStackTrace(e.getStackTrace());
         System.exit(0);
      } catch (Exception e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }

   // 블록을 블록체인에 추가
   public void addBlock(Block newBlock) throws Exception {
      newBlock.mineBlock(difficulty);
      blockList.add(encrypt(newBlock));
   }


   public SealedObject encrypt(Block b) throws Exception {
      SecretKeySpec sks = new SecretKeySpec("MyDifficultPassw".getBytes(), "AES");

      // Create cipher
      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");

      // Code to write your object to file
      cipher.init(Cipher.ENCRYPT_MODE, sks);

      return new SealedObject(b, cipher);
   }

   private boolean checkValidity(Block blockObj) {
      return !hashVotes.contains((String) blockObj.getVoteObj().getVoterPhoneNumber());
   }

   public void sendMsg(MessageStruct msg) throws IOException {
      sendMsg(_socket, msg);
   }

   // Close the socket to exit.
   public void close() {

      String userHomePath = System.getProperty("user.home");
      String fileName;
      fileName = userHomePath + "/Desktop/blockchain_data";
      File f = new File(fileName);

      try {
         if (!f.exists())
            f.createNewFile();
         else {
            f.delete();
            f.createNewFile();
         }

         // Files.setPosixFilePermissions(f.toPath(),
         // EnumSet.of(OWNER_READ, OWNER_WRITE, OWNER_EXECUTE, GROUP_READ,
         // GROUP_EXECUTE));
         System.out.println(fileName);

         ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(fileName, true));
         o.writeObject(blockList);

         o.close();

         _socket.close();

      } catch (IOException e1) {
         // TODO Auto-generated catch block
         e1.printStackTrace();
      }

      System.exit(0);
   }

   @SuppressWarnings("unchecked")
   @Override
   public void msgHandler(MessageStruct msg, Socket src) {
      switch (msg._code) {
      case 0:
         /* message type sent from server to client */
//            System.out.println((String)msg._content.toString()) ;
         try {
            Block decryptedBlock = (Block) decrypt((SealedObject) msg._content); // 블록 해독
            System.out.print("got broadcasted block:");
            System.out.println(decryptedBlock);
            addBlock(decryptedBlock); // 암호화된 블록을 블록체인에 추가
            prevHash = decryptedBlock.getBlockHash(); // **********
            hashVotes.add(decryptedBlock.getVoteObj().getVoterPhoneNumber()); // hashVote 에 clientID 추가
         } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace(); // 예외처리
         }
         break;
      case 1:
         /* message type sent from broadcast to all clients */
         // server manages this
         break;
      case 2:
         clientId = (int) (msg._content);
         break;
      case 3:
         this.parties = msg.parties;
         break;
      case 4:
         voteResultFrame();
         f5.setVisible(false);
         break;
      case 5:
         voteStart();
         f.setVisible(false);
         break;
      case 6:
         // Client send server phoneNumber
         break;
      default:
         break;
      }
   }

   /*
    * Running a loop to receive messages from server. If it fails when receiving,
    * the connections is broken. Close the socket and exit with -1.
    */
   @Override
   public void run() {
      while (true) {
         try {
            receiveMsg(_socket);

         } catch (ClassNotFoundException | IOException e) {
            if (_socket.isClosed()) {
               System.out.println("Bye.");
               System.exit(0);
            }

            System.out.println("Connection to server is broken. Please restart client.");
            close(_socket);
            System.exit(-1);
         }
      }
   }

   private void voteStart() {
      Frame f4 = new Frame("후보 선택");
      f4.setSize(width, height);
      f4.setLayout(new GridLayout(2, 1));
      f4.setVisible(true);

      Wallet myWallet = new Wallet();
      partiesWallet = new ArrayList<Wallet>();

      Label labelArray[] = new Label[parties.size()];
      for (int i = 0; i < parties.size(); i++) {
         Wallet partyWallet = new Wallet();
         partiesWallet.add(partyWallet);
         labelArray[i] = new Label((i + 1) + "번 " + parties.get(i));
         f4.add(labelArray[i]);

      }


      Label l1 = new Label("누구를 투표하시겠습니까? :");
      TextField text1 = new TextField(20);

      Button b = new Button("완료");
      b.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            int voteChoice = Integer.parseInt(text1.getText());
            String voteParty = parties.get(voteChoice - 1);
            Block blockObj = new Block(prevHash);
            blockObj.addVote(myWallet.throwVote(partiesWallet.get(voteChoice - 1).getPublicKey(), voterPhoneNumber, voteParty));
            System.out.print("i add: ");
            System.out.println(blockObj);


            try {
               // 블록 검증
               if (checkValidity(blockObj)) {
                  hashVotes.add(voterPhoneNumber); // voterId 추가, 중복 방지
                  sendMsg(new MessageStruct(1, encrypt(blockObj))); // code : 1 -> 새로운 블록을 브로드캐스팅

                  // addBlock(blockObj); // 블록체인에 추가
                  prevHash = blockObj.getBlockHash(); // prevHash 업데이트
               } else {
                  System.out.println("Vote Invalid.");
               }
            } catch (IOException e1) {
               // TODO Auto-generated catch block
               e1.printStackTrace();
            } catch (Exception e1) {
               // TODO Auto-generated catch block
               e1.printStackTrace();
            }
            try {
               getBlockList().add(encrypt(blockObj));
            } catch (Exception e1) {
               // TODO Auto-generated catch block
               e1.printStackTrace();
            }
            waitingVoteEnd();
            f4.setVisible(false);
         }
      });
      f4.add(l1);
      f4.add(text1);
      f4.add(b);
   }

   private void waitingVoteEnd() {



      f5 = new Frame("투표 종료 대기중");
      f5.setSize(width, height);
      f5.setLayout(new GridLayout(1, 1));
      f5.setVisible(true);
      Label l1 = new Label("투표 종료 대기중...");
      f5.add(l1);
   }

   private void voteResultFrame() {
      Frame f6 = new Frame("투표 결과");
      f6.setSize(width, height);
      f6.setLayout(new GridLayout(2, 1));
      f6.setVisible(true);

      try {
         ArrayList<SealedObject> arr = blockList; // 블록체인
         HashMap<String, Integer> voteMap = new HashMap<>();

         chkBlock.add((Block) decrypt(arr.get(0)));
         System.out.println(chkBlock.get(0));
         System.out.println("arr.size:" + arr.size());
         for(int i = 1; i < arr.size(); i++) {
            Block blk = (Block) decrypt(arr.get(i)); // 블록해독
            System.out.println(blk);
            chkBlock.add(blk);
            String key = blk.getVoteObj().getVoteParty(); // 투표를 받느 후보자의 key

            voteMap.put(key, 0); // HashMap 에 후보자 이름을 키로 등록
         }
         for(int i = 1; i < arr.size(); i++) {
            Block blk = (Block) decrypt(arr.get(i)); // 블록해독
            String key = blk.getVoteObj().getVoteParty(); // 투표를 받느 후보자의 key

            voteMap.put(key, voteMap.get(key) + 1); // 누적된 투표수 + 1
         }


         Label labelArray[] = new Label[parties.size()];
         for (int i = 0; i < parties.size(); i++) {
            /*
            int count=0;

            for (int j=0; j<chkBlock.size(); j++) {
               if(chkBlock.get(j).contains(parties.get(i))) {
                  count++;
               }
               System.out.println("1");
               System.out.println(chkBlock.get(j));
               System.out.println("2");
               System.out.println(parties.get(i));
               System.out.println("3");
            }
            //System.out.println("4");
            */

            //labelArray[i] = new Label((i + 1) + "번 " + parties.get(i) + ": " + Integer.toString(count));
            labelArray[i] = new Label((i + 1) + "번 " + parties.get(i) + ": " + voteMap.get(parties.get(i)) + "표");
            f6.add(labelArray[i]);

         }
         System.out.println(voteMap);

      }
      catch (IOException e1) {
         e1.printStackTrace(); // 예외처리
      } catch (NoSuchPaddingException e) {
         e.printStackTrace(); // 예외처리
      } catch (NoSuchAlgorithmException e) {
         e.printStackTrace(); // 예외처리
      } catch (InvalidKeyException e) {
         e.printStackTrace(); // 예외처리
      }




   }



   public void setVoterPhoneNumber(String text) {
      this.voterPhoneNumber = text;

   }

   public static Object decrypt(SealedObject sealedObject)
         throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
      SecretKeySpec sks = new SecretKeySpec("MyDifficultPassw".getBytes(), "AES");

      // Cipher 생성
      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
      cipher.init(Cipher.DECRYPT_MODE, sks);

      try {
         return sealedObject.getObject(cipher);
      } catch (ClassNotFoundException | IllegalBlockSizeException | BadPaddingException e) {
         e.printStackTrace();
         return null;
      }
   }
}